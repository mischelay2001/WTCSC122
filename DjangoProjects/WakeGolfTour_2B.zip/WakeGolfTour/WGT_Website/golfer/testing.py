from WGT_Website.golfer.models import GolferRoundScores

def main():
    test = GolferRoundScores
    print(test)


main()
